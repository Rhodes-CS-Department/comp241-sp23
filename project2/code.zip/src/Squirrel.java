import squareworld.Board;
import squareworld.Direction;
import squareworld.Location;
import squareworld.actor.Actor;
import java.util.ArrayList;

public class Squirrel extends Actor {
    private RArrayList<Acorn> myAcorns; // acorns this Squirrel is holding
    private RArrayList<Tree> trees;     // all trees the Squirrel knows about
    private int targetTreeIndex;        // which tree the Squirrel is heading towards at the moment
    private int stepsTaken;             // total steps the Squirrel has taken

    public Squirrel() {
        myAcorns = new RArrayList<Acorn>();
        trees = new RArrayList<Tree>();
        targetTreeIndex = 1;    // begin by having the Squirrel head towards tree #1. (0 is their home tree)
        stepsTaken = 0;
    }

    @Override
    public void act() {
        // What tree are we heading towards?
        Tree targetTree = trees.get(targetTreeIndex);

        // Move towards the next tree.
        turnAndMoveTowards(targetTree);
        stepsTaken++;

        // Are we next to the tree?
        if (isNextTo(targetTree)) {
            System.out.println("[Steps=" + stepsTaken + "] Next to tree " + targetTreeIndex + ".");

            // Is this our "home" tree?
            if (targetTreeIndex == 0) {
                System.out.println("Stashing acorns.");
                stashAcorns();
            } else {
                System.out.println("Gathering acorns.");
                gatherAcornsFrom(targetTree);
            }

            // Change our heading towards the next tree.
            targetTreeIndex++;
            if (targetTreeIndex == trees.size()) // is this the last tree?
                targetTreeIndex = 0;    // head home.
        }
    }

    /**
     * This function should let the Squirrel transfer all of the acorns it is carrying to its
     * "nest," which is its home tree (tree #0).  The Squirrel always transfers acorns with weights
     * less than ten to the left side of the nest (prepend) and those with weights 10 or more
     * to the right side (append).
     * If a Squirrel ever arrives at its home tree with no acorns, that means all the other trees
     * are empty, and the Squirrel should remove itself from the board (call removeSelfFromBoard()).
     */
    private void stashAcorns() {
        // YOUR CODE HERE.

        printStatus(); // don't remove this; it's useful for debugging.
    }

    /**
     * This function should let the Squirrel retrieve the FIRST HALF of the acorns in the tree specified.
     * If the tree has an odd number of acorns, the Squirrel will round up to the nearest acorn.
     * Use slice to remove acorns from the tree, and then append the slice to your own list of acorns.
     */
    private void gatherAcornsFrom(Tree whichTree) {
        // YOUR CODE HERE.

        printStatus(); // don't remove this; it's useful for debugging.
    }

    /**
     * This function prints what acorns the Squirrel has as well as the acorns
     * in all the trees.
     */
    public void printStatus() {
        System.out.println("Squirrel: " + myAcorns);
        for (int x = 0; x < trees.size(); x++) {
            System.out.println("Tree " + x + ":   " + trees.get(x).getAcornList());
        }
    }

    /**
     * Add a Tree to this Squirrel's list of Trees.  The first tree added (tree #0) is the
     * Squirrel's "home" tree.
     */
    public void addTree(Tree t) {
        trees.append(t);
    }

    /**
     * Turn the Squirrel toward the Actor specified and take one step forward.
     */
    public void turnAndMoveTowards(Actor actor) {
        Location myLoc = getLocation();
        if (myLoc == null) // Squirrel is no longer on board.
            return;
        Direction dir = myLoc.getDirectionToward(actor.getLocation());
        setDirection(dir);
        moveForward();
    }

    /**
     * Move the Squirrel one unit forward in whatever direction it is facing.
     */
    public void moveForward() {
        Board<Actor> board = getBoard();
        if (board == null) // Squirrel is no longer on board.
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (board.isValid(next))
            moveTo(next);
    }

    /**
     * Returns true if this Squirrel is next to the Actor given as an argument.  "Next to"
     * includes diagonal directions.
     */
    public boolean isNextTo(Actor act) {
        Board<Actor> board = getBoard();
        Location myLoc = getLocation();
        ArrayList<Actor> neighbors = board.getNeighbors(myLoc);
        for (Actor a : neighbors) {
            if (act.equals(a))
                return true;
        }
        return false;
    }
}
