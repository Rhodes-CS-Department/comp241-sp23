import java.util.Arrays;

/**
 * An RArrayList is a dynamic array that can grow in capacity.  It never shrinks in capacity.
 *
 * When adding a single item at a time, if the array would overflow, it always grows by an increment
 * of "SIZE_INCREMENT".
 *
 * When adding multiple items at once, if the array would overflow, the array grows in capacity to
 * accommodate the new items exactly (no extra space at the end).
 */
public class RArrayList<E> implements RList<E> {
    private Object[] data;  // stores the actual array elements.
    private int size;  // stores the size of the array from the user's perspective.
    // We can get the current capacity of the data with data.length.

    private final static int SIZE_INCREMENT = 3;

    /**
     * Create a new RArrayList.  It starts as empty from the user's perspective, but we allocate
     * three slots in our data array.
     */
    public RArrayList() {
        data = new Object[SIZE_INCREMENT];
        size = 0;
    }

    /**
     * Return the size of this array (from the user's perspective).
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Remove all elements in the array (from the user's perspective).
     */
    public void clear() {
        // YOUR CODE HERE (hint: one line!)
    }

    /**
     * Return true if this array is empty (from the user's perspective).
     */
    public boolean isEmpty() {
        // YOUR CODE HERE

        return true; // remove this line when starting (only here so it will compile).
    }

    /**
     * Retrieve the item at position pos.  Throws an IndexOutOfBoundsException if pos
     * is not a legal position (from the user's perspective).
     */
    @Override
    public E get(int pos) throws IndexOutOfBoundsException {
        if (pos < 0 || pos >= size)
            throw new IndexOutOfBoundsException("Tried to access position "
                    + pos + " of an array of size " + size);

        return (E)data[pos];
    }

    /**
     * Set the item at position pos to the value given.  Throws an IndexOutOfBoundsException if pos
     * is not a legal position (from the user's perspective).
     */
    @Override
    public void set(int pos, E value) throws IndexOutOfBoundsException {
        if (pos < 0 || pos >= size)
            throw new IndexOutOfBoundsException("Tried to access position "
                    + pos + " of an array of size " + size);

        data[pos] = value;
    }

    /**
     * Append a new value to the end of this RArrayList.
     * Grow the data array by SIZE_INCREMENT if needed.
     */
    @Override
    public void append(E value) {
        if (size == data.length)    // if the data array is full
            expand();               // grow the data array

        data[size] = value;         // put the new item in place
        size++;                     // increase the size
    }

    /**
     * Append an entire other RArrayList to the end of this RArrayList.  This does not modify
     * the other RArrayList.  If our RArrayList is too small, it should grow by the exact amount
     * necessary to accommodate the new items.  Do not do this by calling append() item by item;
     * instead, expand the data array to fit the new items (if necessary), and use a loop to put
     * them in the right locations.
     */
    public void append(RArrayList<E> other)
    {
        // YOUR CODE HERE
    }

    /**
     * Prepend a new value to the beginning of this RArrayList.
     * Grow the data array by SIZE_INCREMENT if needed.
     */
    @Override
    public void prepend(E value) {
        if (size == data.length)    // if data array is full
            expand();               // grow the data array

        // slide everything to the right so we can put value at [0]
        for (int x = size; x > 0; x--) {
            data[x] = data[x - 1];
        }

        data[0] = value;    // add new value at beginning
        size++;             // increase size
    }

    /**
     * Prepend an entire other RArrayList to the beginning of this RArrayList.  This does not modify
     * the other RArrayList.  If our RArrayList is too small, it should grow by the exact amount
     * necessary to accommodate the new items.  Do not do this by calling prepend() item by item;
     * instead, expand the data array to fit the new items (if necessary), and use a loop to put
     * them in the right locations.
     */
    public void prepend(RArrayList<E> other)
    {
        // YOUR CODE HERE
    }

    /**
     * Get a Python-style "slice" of this RArrayList.  This creates a new RArrayList consisting
     * of all the elements between startPos and endPos-1, inclusive.  This RArrayList is not modified.
     * Make sure that however you choose to implement this, you do not end up expanding the new array
     * more than once, as it wastes time to copy things more than once.
     * Throw an IndexOutOfBoundsException if startPos or endPos are not legal positions.
     */
    public RArrayList<E> slice(int startPos, int endPos) throws IndexOutOfBoundsException
    {
        if (startPos < 0 || startPos >= size)
            throw new IndexOutOfBoundsException("Tried to access position "
                    + startPos + " of an array of size " + size);
        if (endPos < 0 || endPos > size)
            throw new IndexOutOfBoundsException("Tried to access position "
                    + endPos + " of an array of size " + size);

        // YOUR CODE HERE

        return null;  // remove this line when you start (only here so it will compile).
    }

    /**
     * Remove all items between startPos and endPos-1, inclusive.
     * Throw an IndexOutOfBoundsException if startPos or endPos are not legal positions.
     * This does not modify the actual capacity of the data array.
     */
    public void remove(int startPos, int endPos) throws IndexOutOfBoundsException
    {
        if (startPos < 0 || startPos >= size)
            throw new IndexOutOfBoundsException("Tried to access position "
                    + startPos + " of an array of size " + size);
        if (endPos < 0 || endPos > size)
            throw new IndexOutOfBoundsException("Tried to access position "
                    + endPos + " of an array of size " + size);

        // YOUR CODE HERE
    }

    /**
     * Return a representation of this RArrayList from the user's perspective.
     */
    @Override
    public String toString() {
        // Build a string that represents how the user perceives the array:
        String dataString = "[ ";
        for (int x = 0; x < size; x++)
            dataString += (data[x] + " ");
        dataString += "]";
        return dataString;
    }

    /**
     * Return a String that represents the internal representation of
     * this RArrayList.  Note that normally this sort of information is not
     * usually made public through a function like this, but we want to use it for
     * debugging.
     */
    public String toInternalString() {
        // Build a string that represents how the user perceives the array:
        String dataString = "user view=[ ";
        for (int x = 0; x < size; x++)
            dataString += (data[x] + " ");
        dataString += "] ";

        // Add in the internal representation:
        dataString += ("internal view=" + Arrays.toString(data));
        return dataString + " size=" + size + " capacity=" + data.length;
    }

    /**
     * Expand the data array by SIZE_INCREMENT slots.
     */
    private void expand()
    {
        int newCapacity = data.length + SIZE_INCREMENT;   // calculate the new capacity
        Object[] newData = new Object[newCapacity];

        // copy old data into new data
        for (int x = 0; x < size; x++)
        {
            newData[x] = data[x];
        }

        data = newData; // reassign
    }

    /**
     * Expand the data array to be the exact newCapacity specified.  We assume
     * newCapacity >= the existing capacity.
     */
    private void expandToCapacity(int newCapacity)
    {
        // YOUR CODE HERE
    }
}
