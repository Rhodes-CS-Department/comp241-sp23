package squareworld;

import squareworld.actor.Actor;
import squareworld.actor.ActorUpdatePolicy;
import squareworld.gui.BoardManagerFrame;

/**
 * A BoardManager takes care of managing a Board of objects by updating them when asked according
 * to a policy, and also by drawing them in text or graphics.
 */
public class BoardManager<T> {
    private Board<T> board;
    private BoardUpdatePolicy<T> updatePolicy;
    int stepsTaken;

    /**
     * Create a new Board Manager.
     */
    public BoardManager(Board<T> board, BoardUpdatePolicy<T> updatePolicy) {
        this.board = board;
        this.updatePolicy = updatePolicy;
        this.stepsTaken = 0;
    }

    /**
     * Take one step in the board (one update).
     */
    public void step() {
        board = updatePolicy.updateBoard(board);
        stepsTaken++;
    }

    /**
     * Return the total steps taken so far (total updates).
     */
    public int getStepsTaken() {
        return stepsTaken;
    }

    /**
     * Display a board visually and allow the user to interact with it.
     */
    public void display() {
        BoardManagerFrame f = new BoardManagerFrame(this);
        f.setVisible(true);
    }

    /**
     * Convenience method to take a number of steps and textually print them
     * to the screen as they are done.
     */
    public void stepAndPrint(int steps) {
        System.out.println("Step " + stepsTaken + ":");
        System.out.println();
        System.out.println(toDisplayString());
        for (int x = 0; x < steps; x++) {
            step();
            System.out.println("Step " + stepsTaken + ":");
            System.out.println();
            System.out.println(toDisplayString());
            //System.out.println(board);
        }
    }

    /**
     * Return the board.
     */
    public Board<T> getBoard() {
        return board;
    }

    /**
     * Return a String representing the board as text.  Board objects are
     * shown as their characters from BoardObject.getBoardChar().
     */
    public String toDisplayString() {
        String s = "";

        int rmin = 0;
        int rmax = board.getNumRows() - 1;
        int cmin = 0;
        int cmax = board.getNumCols() - 1;
        if (rmax < 0 || cmax < 0) // unbounded grid
        {
            for (Location loc : board.getOccupiedLocations()) {
                int r = loc.getRow();
                int c = loc.getCol();
                if (r < rmin)
                    rmin = r;
                if (r > rmax)
                    rmax = r;
                if (c < cmin)
                    cmin = c;
                if (c > cmax)
                    cmax = c;
            }
        }

        for (int i = rmin; i <= rmax; i++) {
            for (int j = cmin; j <= cmax; j++) {
                Object obj = board.get(new Location(i, j));
                if (obj == null)
                    s += ".";
                else if (obj instanceof BoardObject)
                    s += ((BoardObject) obj).getBoardChar();
                else
                    s += obj.toString().substring(0, 1);
            }
            s += "\n";
        }
        return s;

    }
}
