package squareworld;

/**
 * An Orientable object always has a direction, therefore you can
 * call getDirection on it.
 */
public interface Orientable {
    public Direction getDirection();
}
