package squareworld.actor;

import squareworld.Direction;
import squareworld.Location;

/**
 * A Flower is an actor that stays in one place but
 * turns 45 degrees on each update.
 */

public class Flower extends Actor
{
    /**
     * A Flower, when it acts, turns 45 degrees clockwise.
     */
    @Override
    public void act()
    {
        // Get the current direction that we are facing.
        Direction myDirection = getDirection();

        // Compute the new direction, which is 45 degrees clockwise.
        Direction newDirection = myDirection.rotateClockwise(45);

        // Turn the flower to our new direction.
        setDirection(newDirection);

        // The lines below are for demonstration/debug purposes.  Remove them when you start
        // implementing the project.
        Location loc = getLocation();
        Direction dir = getDirection();
        System.out.println("I am a flower at location " + loc + " and direction " + dir);
    }

}
