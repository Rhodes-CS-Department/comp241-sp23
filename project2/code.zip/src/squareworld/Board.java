package squareworld;

import java.util.*;

/**
 * A Board is a rectangular grid with a finite number of
 * rows and columns.
 */
public class Board<T> {
    private Object[][] occupantArray; // the array storing the board elements

    /**
     * Constructs an empty bounded board with the given dimensions.
     * (Precondition: rows > 0 and cols > 0.)
     *
     * @param rows number of rows in the Board
     * @param cols number of columns in the Board
     */
    public Board(int rows, int cols) {
        if (rows <= 0)
            throw new IllegalArgumentException("rows <= 0");
        if (cols <= 0)
            throw new IllegalArgumentException("cols <= 0");
        occupantArray = new Object[rows][cols];
    }

    /**
     * Returns the number of rows in this board.
     *
     * @return the number of rows, or -1 if this board is unbounded
     */
    public int getNumRows() {
        return occupantArray.length;
    }

    /**
     * Returns the number of columns in this board.
     *
     * @return the number of columns, or -1 if this board is unbounded
     */
    public int getNumCols() {
        // Note: according to the constructor precondition, numRows() > 0, so
        // theboard[0] is non-null.
        return occupantArray[0].length;
    }

    /**
     * Checks whether a location is valid in this board. <br />
     * Precondition: <code>loc</code> is not <code>null</code>
     *
     * @param loc the location to check
     * @return <code>true</code> if <code>loc</code> is valid in this board,
     * <code>false</code> otherwise
     */
    public boolean isValid(Location loc) {
        return 0 <= loc.getRow() && loc.getRow() < getNumRows()
                && 0 <= loc.getCol() && loc.getCol() < getNumCols();
    }

    /**
     * Gets the locations in this board that contain objects.
     * @return an array list of all occupied locations in this board
     */
    public ArrayList<Location> getOccupiedLocations() {
        ArrayList<Location> theLocations = new ArrayList<Location>();

        // Look at all board locations.
        for (int r = 0; r < getNumRows(); r++) {
            for (int c = 0; c < getNumCols(); c++) {
                // If there's an object at this location, put it in the array.
                Location loc = new Location(r, c);
                if (get(loc) != null)
                    theLocations.add(loc);
            }
        }

        return theLocations;
    }

    /**
     * Returns the object at a given location in this board. <br />
     * Precondition: <code>loc</code> is valid in this board
     *
     * @param loc a location in this board
     * @return the object at location <code>loc</code> (or <code>null<code>
     * if the location is unoccupied)
     */
    public T get(Location loc) {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        return (T) occupantArray[loc.getRow()][loc.getCol()]; // unavoidable warning
    }

    /**
     * Puts an object at a given location in this board. <br />
     * Precondition: (1) <code>loc</code> is valid in this board (2)
     * <code>obj</code> is not <code>null</code>
     *
     * @param loc the location at which to put the object
     * @param obj the new object to be added
     * @return the object previously at <code>loc</code> (or <code>null</code>
     * if the location was previously unoccupied)
     */
    public T put(Location loc, T obj) {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        if (obj == null)
            throw new NullPointerException("obj == null");

        // Add the object to the board.
        T oldOccupant = get(loc);
        occupantArray[loc.getRow()][loc.getCol()] = obj;
        return oldOccupant;
    }

    /**
     * Removes the object at a given location from this board. <br />
     * Precondition: <code>loc</code> is valid in this board
     *
     * @param loc the location of the object that is to be removed
     * @return the object that was removed (or <code>null<code> if the location
     * is unoccupied)
     */
    public T remove(Location loc) {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");

        // Remove the object from the board.
        T r = get(loc);
        occupantArray[loc.getRow()][loc.getCol()] = null;
        return r;
    }

    /**
     * Gets the neighboring occupants in all eight compass directions (north,
     * northeast, east, southeast, south, southwest, west, and northwest).
     * <br />
     * Precondition: <code>loc</code> is valid in this board
     *
     * @param loc a location in this board
     * @return returns an array list of the objects in the occupied locations
     * adjacent to <code>loc</code> in this board
     */
    public ArrayList<T> getNeighbors(Location loc) {
        ArrayList<T> neighbors = new ArrayList<>();
        for (Location neighborLoc : getOccupiedAdjacentLocations(loc))
            neighbors.add(get(neighborLoc));
        return neighbors;
    }

    /**
     * Gets the valid locations adjacent to a given location in all eight
     * compass directions (north, northeast, east, southeast, south, southwest,
     * west, and northwest). <br />
     * Precondition: <code>loc</code> is valid in this board
     *
     * @param loc a location in this board
     * @return an array list of the valid locations adjacent to <code>loc</code>
     * in this board
     */
    public ArrayList<Location> getValidAdjacentLocations(Location loc) {
        ArrayList<Location> locs = new ArrayList<>();

        for (Direction d : Direction.values()) {
            Location neighborLoc = loc.getAdjacentLocation(d);
            if (isValid(neighborLoc))
                locs.add(neighborLoc);
        }
        return locs;
    }

    /**
     * Gets the valid empty locations adjacent to a given location in all eight
     * compass directions (north, northeast, east, southeast, south, southwest,
     * west, and northwest). <br />
     * Precondition: <code>loc</code> is valid in this board
     *
     * @param loc a location in this board
     * @return an array list of the valid empty locations adjacent to
     * <code>loc</code> in this board
     */
    public ArrayList<Location> getEmptyAdjacentLocations(Location loc) {
        ArrayList<Location> locs = new ArrayList<>();
        for (Location neighborLoc : getValidAdjacentLocations(loc)) {
            if (get(neighborLoc) == null)
                locs.add(neighborLoc);
        }
        return locs;
    }

    /**
     * Gets the valid occupied locations adjacent to a given location in all
     * eight compass directions (north, northeast, east, southeast, south,
     * southwest, west, and northwest). <br />
     * Precondition: <code>loc</code> is valid in this board
     *
     * @param loc a location in this board
     * @return an array list of the valid occupied locations adjacent to
     * <code>loc</code> in this board
     */
    public ArrayList<Location> getOccupiedAdjacentLocations(Location loc) {
        ArrayList<Location> locs = new ArrayList<>();
        for (Location neighborLoc : getValidAdjacentLocations(loc)) {
            if (get(neighborLoc) != null)
                locs.add(neighborLoc);
        }
        return locs;
    }

    /**
     * Creates a string that describes this board.
     *
     * @return a string with descriptions of all objects in this board (not
     * necessarily in any particular order), in the format {loc=obj, loc=obj,
     * ...}
     */
    public String toString() {
        String s = "{";
        for (Location loc : getOccupiedLocations()) {
            if (s.length() > 1)
                s += ", ";
            s += loc + "=" + get(loc);
        }
        return s + "}";
    }
}


