package nothanks;

import sortedlist.SortedList;

public class CardScore {

    /**
     * Return the "card score" for a final set of cards held by a player.
     * The score is the sum of all the numbers on the cards held, except that a streak of cards
     * counts only the lowest card in each streak.
     */
    public static int getCardScore(SortedList<Integer> cards) {
        // Your code here.
        return 0;  // remove this line.
    }

    public static void main(String[] args) {
        SortedList<Integer> slist = new SortedList<>();
        slist.add(10);
        slist.add(12);
        System.out.println("Card score for " + slist
                + " is " + getCardScore(slist)); // should be 22
        slist.add(11);
        System.out.println("Card score for " + slist
                + " is " + getCardScore(slist)); // should be 10

        slist.clear();
        // Write more tests here.
    }
}