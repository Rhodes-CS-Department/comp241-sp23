/**
 * An Acorn object just has a weight.
 */
public class Acorn {
    private final int weight;

    /**
     * Create a new Acorn with a given weight.
     */
    public Acorn(int weight) {
        this.weight = weight;
    }

    /**
     * Get the weight of this acorn.
     */
    public int getWeight() {
        return weight;
    }

    public String toString() {
        return "" + getWeight();
    }
}
