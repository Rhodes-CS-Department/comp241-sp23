/**
 * This class exists solely to test the functionality of RArrayList.
 */
public class RArrayListTester {
    public static void main(String[] args)
    {
        testAppend();
        testPrepend();
        /* You should write other methods to test the following:s
            - prepend (multiple item version)
            - append (multiple item version)
            - slice
            - remove

            Each of these test functions should try to test as many different cases that you
            can think of, so you can be 100% sure your methods work correctly.  (You obviously should
            inspect your output so you know it's correct.)   :-)

            For example, for slice, you should try slicing from the beginning, middle, and end.
            Try slicing one item and multiple items.  What happens if you give slice bad arguments?
         */
    }

    private static void testAppend()
    {
        RArrayList<Integer> mylist = new RArrayList<Integer>();
        System.out.println(mylist.toInternalString());
        mylist.append(7);
        System.out.println(mylist.toInternalString());
        mylist.append(9);
        System.out.println(mylist.toInternalString());
        mylist.append(2);
        System.out.println(mylist.toInternalString());
        mylist.append(-1);
        System.out.println(mylist.toInternalString());
    }

    private static void testPrepend()
    {
        RArrayList<Integer> mylist = new RArrayList<Integer>();
        System.out.println(mylist.toInternalString());
        mylist.prepend(7);
        System.out.println(mylist.toInternalString());
        mylist.prepend(9);
        System.out.println(mylist.toInternalString());
        mylist.prepend(2);
        System.out.println(mylist.toInternalString());
        mylist.prepend(-1);
        System.out.println(mylist.toInternalString());
    }
}
