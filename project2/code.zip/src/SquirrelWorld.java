import squareworld.Board;
import squareworld.BoardManager;
import squareworld.Location;
import squareworld.actor.*;
import java.io.InputStream;
import java.util.Scanner;

public class SquirrelWorld {

    public static void main(String[] args)
    {
        System.out.print("What file do you want to read? ");
        Scanner scan = new Scanner(System.in);
        String filename = scan.nextLine();

        Board<Actor> board = loadBoard(filename);

        ActorUpdatePolicy policy = new ActorUpdatePolicy();
        BoardManager<Actor> boardManager = new BoardManager<Actor>(board, policy);
        boardManager.display();
    }

    /**
     * Read the file specified and add all appropriate Actors (Squirrels and Trees)
     * to a new board.  Make sure the Squirrel knows about all the Trees.
     */
    public static Board<Actor> loadBoard(String filename)
    {
        Board<Actor> board;
        InputStream is = SquirrelWorld.class.getResourceAsStream(filename);
        if (is == null) {
            System.err.println("Bad filename: " + filename);
            System.exit(1);
        }
        Scanner scan = new Scanner(is);
        int rows = scan.nextInt();
        int cols = scan.nextInt();
        board = new Board<Actor>(rows, cols);
        Squirrel squirrel = null;

        while (scan.hasNext()) {
            String type = scan.next();
            if (type.equals("squirrel")) {
                int row = scan.nextInt();   // read squirrel's row
                int col = scan.nextInt();   // read squirrel's column
                squirrel = new Squirrel();
                squirrel.addSelfToBoard(board, new Location(row, col));
                //System.out.println(squirrel);
            } else if (type.equals("tree")) {
                int row = scan.nextInt();   // read tree row
                int col = scan.nextInt();   // read tree column
                Tree tree = new Tree();
                int weight = scan.nextInt();    // read first acorn's weight
                while (weight > 0) {            // keep reading until we get a zero weight
                    tree.getAcornList().append(new Acorn(weight));
                    weight = scan.nextInt();    // read again
                }
                tree.addSelfToBoard(board, new Location(row, col));
                squirrel.addTree(tree);     // notify the squirrel that we've added a tree
            }
        }
        System.out.println("Starting configuration:");
        squirrel.printStatus();
        return board;
    }
}
