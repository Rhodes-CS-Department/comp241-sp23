import squareworld.actor.Actor;

/**
 * A Tree is an Actor that stays in one place, but holds a List of Acorns.
 */
public class Tree extends Actor {

    private final RArrayList<Acorn> acorns; // Acorns currently on the tree.

    /**
     * Create a new Tree with no acorns.
     */
    public Tree() {
        acorns = new RArrayList<Acorn>();
    }

    /**
     * Access all the acorns currently on the tree.  Note that this function
     */
    public RArrayList<Acorn> getAcornList() {
        return acorns;
    }

    /**
     * A tree doesn't move.
     */
    @Override
    public void act() {
        // A tree does nothing.
    }
}
