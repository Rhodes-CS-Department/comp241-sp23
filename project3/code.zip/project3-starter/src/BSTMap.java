import java.util.ArrayList;
import java.util.List;

/**
 * A map implemented with a binary search tree.
 */
public class BSTMap<K extends Comparable<K>, V> {

    private Node root; // points to the root of the BST.

    /**
     * Create a new, empty BST.
     */
    public BSTMap() {
        root = null;
    }

    /**
     * Put (add a key-value pair) into this BST. If the key already exists, the old
     * value will be overwritten with the new one.
     */
    public void put(K newKey, V newValue) {
        // Your code here.
        // This function should call the helper function `put` below.
    }

    /**
     * Helper function for put.
     */
    private void put(Node curr, K newKey, V newValue) {
        // Your code here.
    }

    /**
     * Get a value from this BST, based on its key. If the key doesn't already exist in the BST,
     * this method returns null.
     */
    public V get(K searchKey) {
        return null; // remove this.
        // Your code here.
    }

    /**
     * Test if a key is present in this BST. Returns true if the key is found, false if not.
     */
    public boolean containsKey(K searchKey) {
        return true; // remove this.
        // Your code here.
    }

    /**
     * Given a key, remove the corresponding key-value pair from this BST. If the key is not found, do nothing.
     */
    public void remove(K removeKey) {
        // Your code here.
    }

    /**
     * Return the number of key-value pairs in this BST.
     */
    public int size() {
        return 0; // remove this.
        // Your code here.
    }

    /**
     * Return the height of this BST.
     */
    public int height() {
        return 0; // remove this.
        // Your code here.
    }

    /**
     * Return a List of the keys in this BST, ordered by a preorder traversal.
     */
    public List<K> preorderKeys() {
        return null; // remove this.
        // Your code here.
    }

    /**
     * Return a List of the keys in this BST, ordered by a inorder traversal.
     */
    public List<K> inorderKeys() {
        return null; // remove this.
        // Your code here.
    }

    /**
     * Return a List of the keys in this BST, ordered by a postorder traversal.
     */
    public List<K> postorderKeys() {
        return null; // remove this.
        // Your code here.
    }

    /**
     * It is very common to have private classes nested inside other classes. This is most commonly used when
     * the nested class has no meaning apart from being a helper class or utility class for the outside class.
     * In this case, this Node class has no meaning outside of this BSTMap class, so we nest it inside here
     * so as to not prevent another class from declaring a Node class as well.
     */
    private class Node {
        public K key = null;
        public V value = null;
        public Node left = null;
        public Node right = null;

        // Add a constructor here if you'd like.
        // If no constructor is defined, you get the default constructor, `new Node()`.
    }
}
