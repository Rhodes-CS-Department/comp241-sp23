import squareworld.Board;
import squareworld.Direction;
import squareworld.Location;
import squareworld.actor.Actor;
import squareworld.actor.Flower;

/**
 * A Mouse is an Actor that finds a Flower in a maze by following the
 * wall on its right at all times.  Whenever the flower is directly
 * north, south, east, or west, the Mouse stops and prints the total
 * number of steps it has taken.
 */
public class Mouse extends Actor {
    // Fields here if you want.

    @Override
    public void act() {
        // Your code here.
    }
}