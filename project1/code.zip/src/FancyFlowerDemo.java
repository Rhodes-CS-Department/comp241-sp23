import squareworld.Board;
import squareworld.BoardManager;
import squareworld.actor.FancyFlower;
import squareworld.Location;
import squareworld.actor.*;

/**
 * This class demonstrates the FancyFlower class.
 */
public class FancyFlowerDemo
{
    public static void main(String[] args)
    {
        Board<Actor> board = new Board<Actor>(1, 4);

        FancyFlower f1 = new FancyFlower(45);
        FancyFlower f2 = new FancyFlower(90);
        FancyFlower f3 = new FancyFlower(-45);
        FancyFlower f4 = new FancyFlower(-90);

        f1.addSelfToBoard(board, new Location(0, 0));
        f2.addSelfToBoard(board, new Location(0, 1));
        f3.addSelfToBoard(board, new Location(0, 2));
        f4.addSelfToBoard(board, new Location(0, 3));

        BoardManager<Actor> manager = new BoardManager<Actor>(board, new ActorUpdatePolicy());
        manager.display();
    }
}
