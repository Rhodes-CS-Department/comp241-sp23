package squareworld;

/**
 * A BoardUpdatePolicy stores the update procedure used to change a board.
 * For instance, all objects may move one at a time, or they may move simultaneously,
 * or some objects might always move before others.
 */
public interface BoardUpdatePolicy<T> {
    /**
     * Return a new board that should replace the existing board.  Inside this function
     * the board should update.  The return value may be the same board, or a brand new one.
     */
    public Board<T> updateBoard(Board<T> board);
}
