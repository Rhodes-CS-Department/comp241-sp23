import squareworld.actor.Bug;

/**
 * A SquareBug is a bug that draws a square of flowers from its
 * starting location.  The length of the side of the square is
 * specified in the constructor.
 */
public class SquareBug extends Bug
{
    // Add fields here.

    public SquareBug(int sideLength)
    {
        // Fill in constructor.
    }

    @Override
    public void act()
    {
        // Fill in code for act() here.
    }
}
